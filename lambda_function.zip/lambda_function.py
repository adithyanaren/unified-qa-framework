import json
import logging
import boto3
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# CloudWatch client
cloudwatch = boto3.client("cloudwatch")
NAMESPACE = "QAFramework/Serverless"
METRIC_NAME = "RequestsProcessed"
STAGE = os.getenv("STAGE", "dev")

def lambda_handler(event, context):
    path = event.get("rawPath", "/")

    headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type,Authorization"
    }

    # Handle preflight request (OPTIONS)
    if event.get("requestContext", {}).get("http", {}).get("method") == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": ""
        }

    # Main route
    if path == "/":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": '{"message": "Hello from your first Lambda!"}'
        }
    else:
        return {
            "statusCode": 404,
            "headers": headers,
            "body": '{"error": "Not Found"}'
        }
